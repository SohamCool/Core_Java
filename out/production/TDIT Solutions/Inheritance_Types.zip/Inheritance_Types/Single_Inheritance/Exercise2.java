package Inheritance_Types.Single_Inheritance;
class Parent{
    public void display(){
        System.out.println("In parent class");
    }
}
public class Exercise2 extends Parent {
    public static void main(String[] args) {
        Exercise2 obj = new Exercise2();
        obj.display();
    }
}
