package Inheritance_Types.Multiple_Inheritance;

public interface SalaryAccount{
    int accID = 201;
    String bankName = "HDFC bank";
    public void showSalaryAccount();
}
