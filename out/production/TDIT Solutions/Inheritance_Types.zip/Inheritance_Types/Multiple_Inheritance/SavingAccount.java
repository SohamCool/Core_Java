package Inheritance_Types.Multiple_Inheritance;

public interface SavingAccount {
    int accID = 101;
    String bankName = "Canara bank";
    public void showSavingAccount();
}
